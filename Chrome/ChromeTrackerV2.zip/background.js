chrome.runtime.onInstalled.addListener(() => {
    console.log("Chromebook Number Submitter extension installed.");
  });
  