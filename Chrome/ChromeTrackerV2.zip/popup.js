document.getElementById("chromebook-form").addEventListener("submit", async (event) => {
  event.preventDefault();

  document.getElementById("chromebook-form").style.display = "none";
  document.getElementById("sent-message").style.display = "block";

  const chromebookNumber = document.getElementById("chromebook-number").value;
  if (!chromebookNumber) return;

  // Replace with your server URL
  const url = "https://script.google.com/macros/s/AKfycbxg8Ff4GuH5DX00reLkVbH3VA7gS03JKF6kEJEWY5Zbhg6PtbMuqNYkVQXFihIfmY21/exec";

  // Initialize UUID, Serial Number, and userEmail as empty strings
  let uuid = "UUID";
  let serialNumber = "SERIALNO";
  let userEmail = "EMAIL";

  // Check if enterprise APIs are available and fetch UUID and Serial Number if possible
  if (chrome.enterprise && chrome.enterprise.deviceAttributes) {
    chrome.enterprise.deviceAttributes.getDeviceSerialNumber((serial) => {
      serialNumber = serial || "";

      chrome.enterprise.deviceAttributes.getDirectoryDeviceId((deviceId) => {
        uuid = deviceId || "";

        // Fetch user email using the chrome.identity API
        getUserEmail().then((email) => {
          userEmail = email || "";
          submitData(url, chromebookNumber, uuid, serialNumber, userEmail);
        });
      });
    });
  } else {
    // Fetch user email and submit data if not on an enterprise device
    getUserEmail().then((email) => {
      userEmail = email || "";
      submitData(url, chromebookNumber, uuid, serialNumber, userEmail);
    });
  }
});

async function getUserEmail() {
  return new Promise((resolve) => {
    chrome.identity.getProfileUserInfo((userInfo) => {
      resolve(userInfo.email || "");
    });
  });
}

async function submitData(url, chromebookNumber, uuid, serialNumber, userEmail) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chromebookNumber,
        uuid,
        serialNumber,
        userEmail
      })
    });

    // console.log(response);

    if (response.ok) {
      // alert("Chromebook information submitted successfully!");
    } else {
      // alert("Failed to submit Chromebook information.");
    }
  } catch (error) {
    console.error("Error submitting Chromebook information:", error);
    // alert("An error occurred.");
  }
}
